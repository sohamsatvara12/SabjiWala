<?php
session_start();
@include 'component/config.php';

if (isset($_POST['add_product'])) {

   $p_category = $_POST['p_category'];
   $p_name = $_POST['p_name'];
   $p_price = $_POST['p_price'];
   $p_image = $_FILES['p_image']['name'];
   $p_image_tmp_name = $_FILES['p_image']['tmp_name'];

   if ($p_category == 'fruit') {
      $p_image_folder = 'images/fruit_dairy/' . $p_image;
   } elseif ($p_category == 'vegetable') {
      $p_image_folder = 'images/vegetables/' . $p_image;
   } elseif ($p_category == 'dairy') {
      $p_image_folder = 'images/fruit_dairy/' . $p_image;
   }

   $insert_query = mysqli_query($conn, "INSERT INTO `products`(category,name, price, image) VALUES('$p_category','$p_name', '$p_price', '$p_image')") or die('query failed');

   if ($insert_query) {
      move_uploaded_file($p_image_tmp_name, $p_image_folder);
      $message[] = 'product added succesfully';
   } else {
      $message[] = 'could not add the product';
   }
};

if (isset($_GET['delete'])) {
   $delete_id = $_GET['delete'];
   $delete_query = mysqli_query($conn, "DELETE FROM `products` WHERE id = $delete_id ") or die('query failed');
   if ($delete_query) {
      $message[] = 'product has been deleted';
   } else {
      $message[] =  'product could not be deleted';
   };
};

if (isset($_POST['update_product'])) {

   $update_p_id = $_POST['update_p_id'];
   $update_p_category = $_POST['update_p_category'];
   $update_p_name = $_POST['update_p_name'];
   $update_p_price = $_POST['update_p_price'];
   $update_p_image = $_FILES['update_p_image']['name'];
   $update_p_image_tmp_name = $_FILES['update_p_image']['tmp_name'];

   if ($update_p_category == 'fruit') {
      $update_p_image_folder = 'images/fruit_dairy/' . $update_p_image;
   } elseif ($update_p_category == 'vegetable') {
      $update_p_image_folder = 'images/vegetables/' . $update_p_image;
   } elseif ($update_p_category == 'dairy') {
      $update_p_image_folder = 'images/fruit_dairy/' . $update_p_image;
   } else {
      $update_p_image_folder = 'images/' . $update_p_image;
   }

   $update_query = mysqli_query($conn, "UPDATE `products` SET category = '$update_p_category', name = '$update_p_name', price = '$update_p_price', image = '$update_p_image' WHERE id = '$update_p_id'");

   if ($update_query) {
      move_uploaded_file($update_p_image_tmp_name, $update_p_image_folder);
      $message[] =   'product updated succesfully';
      // header('location:admin.php');
   } else {
      $message[] = 'product could not be updated';
      // header('location:admin.php');
   }
};


?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Admin panel</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="css/AddUpdateShow.css">

   

</head>

<body>

   <?php include 'component/msg.php'; ?>

   <?php include 'component/header.php'; ?>

   <h1 class="heading" style="margin-top:9.5rem;">Admin<span>panel</span></h1>
   <div class="container">

      <section style=" margin-top: -7rem;">

         <form action="" method="post" class="add-product-form" enctype="multipart/form-data">
            <h3>add a new product</h3>
            <select name="p_category" class="box" required>
               <option value="" selected disabled>select a category</option>
               <option value="vegetable">Vegetable</option>
               <option value="fruit">Fruit</option>
               <option value="dairy">Dairy</option>
               <!-- add more options as needed -->
            </select>
            <input type="text" name="p_name" placeholder="enter the product name" class="box" required>
            <input type="number" name="p_price" min="0" placeholder="enter the product price" class="box" required>
            <input type="file" name="p_image" accept="image/png, image/jpg, image/jpeg" class="box" required>

            <input type="submit" value="add the product" name="add_product" class="btn">
         </form>



      </section>

      <section class="display-product-table">

         <table>

            <thead>
               <th>product image</th>
               <th>product category</th>
               <th>product name</th>
               <th>product price</th>
               <th>action</th>
            </thead>

            <tbody>
               <?php

               $select_products = mysqli_query($conn, "SELECT * FROM `products`");
               if (mysqli_num_rows($select_products) > 0) {
                  while ($row = mysqli_fetch_assoc($select_products)) {
               ?>

                     <tr>
                        <td><img src="<?php
                                       if ($row['category'] == 'vegetable') {
                                          echo 'images/vegetables/';
                                       } elseif ($row['category'] == 'fruit') {
                                          echo 'images/fruit_dairy/';
                                       } elseif ($row['category'] == 'dairy') {
                                          echo 'images/fruit_dairy/';
                                       } else {
                                          echo 'uploaded_img/';
                                       }
                                       echo $row['image']; ?>" height="100" alt=""></td>

                        <td><?php echo $row['category']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td>$<?php echo $row['price']; ?>/-</td>
                        <td>
                           <a href="admin.php?delete=<?php echo $row['id']; ?>" class="delete-btn" onclick="return confirm('are your sure you want to delete this?');"> <i class="fas fa-trash"></i> delete </a>
                           <a href="admin.php?edit=<?php echo $row['id']; ?>" class="option-btn"> <i class="fas fa-edit"></i> update </a>

                        </td>
                     </tr>

               <?php
                  };
               } else {
                  echo "<div class='empty'>no product added</div>";
               };
               ?>
            </tbody>
         </table>

      </section>

      <section class="edit-form-container">

         <?php

         if (isset($_GET['edit'])) {
            $edit_id = $_GET['edit'];
            $edit_query = mysqli_query($conn, "SELECT * FROM `products` WHERE id = $edit_id");
            if (mysqli_num_rows($edit_query) > 0) {
               while ($fetch_edit = mysqli_fetch_assoc($edit_query)) {
         ?>

                  <form action="" method="post" enctype="multipart/form-data">


                     <?php
                     if ($fetch_edit['category'] == 'fruit') {
                        $img_src = 'images/fruit_dairy/' . $fetch_edit['image'];
                     } elseif ($fetch_edit['category'] == 'vegetable') {
                        $img_src = 'images/vegetables/' . $fetch_edit['image'];
                     } elseif ($fetch_edit['category'] == 'dairy') {
                        $img_src = 'images/fruit_dairy/' . $fetch_edit['image'];
                     } else {
                        $img_src = 'uploaded_img/' . $fetch_edit['image'];
                     }
                     ?>

                     <img src="<?php echo $img_src; ?>" height="200" alt="">

                     <input type="hidden" name="update_p_id" value="<?php echo $fetch_edit['id']; ?>">
                     <input type="text" class="box" required name="update_p_name" value="<?php echo $fetch_edit['name']; ?>">
                     <input type="number" min="0" class="box" required name="update_p_price" value="<?php echo $fetch_edit['price']; ?>">
                     <select name="update_p_category" class="box" required>
                        <option value="">-- select category --</option>
                        <option value="fruit" <?php if ($fetch_edit['category'] == 'fruit') {
                                                   echo 'selected';
                                                } ?>>fruit</option>
                        <option value="vegetable" <?php if ($fetch_edit['category'] == 'vegetable') {
                                                      echo 'selected';
                                                   } ?>>vegetable</option>
                        <option value="dairy" <?php if ($fetch_edit['category'] == 'dairy') {
                                                   echo 'selected';
                                                } ?>>dairy</option>
                     </select>
                     <input type="file" class="box" required name="update_p_image" accept="image/png, image/jpg, image/jpeg">
                     <input type="submit" value="update the prodcut" name="update_product" class="btn">
                     <input type="reset" value="cancel" id="close-edit" class="option-btn">
                     <script>
                        // select the cancel button element by its id
                        const cancelButton = document.getElementById('close-edit');

                        // add a click event listener to the cancel button
                        cancelButton.addEventListener('click', function(e) {
                           e.preventDefault(); // prevent the default form submission behavior
                           window.location.href = 'admin.php'; // redirect to the admin page
                        });
                        // select the update button element by its class
                        const updateButton = document.querySelector('.option-btn');

                        // add a click event listener to the update button
                        updateButton.addEventListener('click', function(e) {
                           e.preventDefault(); // prevent the default link behavior
                           const editFormContainer = document.querySelector('.edit-form-container');
                           editFormContainer.style.display = 'none';
                        });
                     </script>

                  </form>

         <?php
               };
            };
            echo "<script>document.querySelector('.edit-form-container').style.display = 'flex';</script>";
         };
         ?>

      </section>
   </div>

   <?php include 'component/footer.php'; ?>
</body>
<script src="js/script.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
</html>