<section class="features" id="features">
        <h1 class="heading" style="margin-bottom: 2rem;">Our <span>features</span></h1>


        <div class="box-container">

            <div class="box">
                <img src="images/feature1.png" alt="">
                <h3>Fresh and Organic</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus, atque!</p>
                <a href="#" class="btn">read more</a>
            </div>


            <div class="box">
                <img src="images/feature2.png" alt="">
                <h3>Free Delivery</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus, atque!</p>
                <a href="#" class="btn">read more</a>
            </div>


            <div class="box">
                <img src="images/feature3.png" alt="">
                <h3>Easy and Fast Payments</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus, atque!</p>
                <a href="#" class="btn">read more</a>
            </div>

        </div>
    </section>
