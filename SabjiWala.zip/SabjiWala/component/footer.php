
 <!-- Footer Section -->

 <section class="footer">
        <div class="box-container">


            <div class="box">
                <h3>SabjiWala <i class="fas fa-shopping-basket"></i></h3>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ipsam, modi?</p>
                <div class="share">
                    <a href="" class="fab fa-facebook-f"></a>
                    <a href="" class="fab fa-twitter"></a>
                    <a href="" class="fab fa-instagram"></a>
                    <a href="" class="fab fa-linkedin"></a>
                </div>
            </div>

            <div class="box">
                <h3>contact info</h3>

                <a href="#" class="links"><i class="fas fa-phone"></i> +91 98765 43210</a>
                <a href="#" class="links" style="text-transform:none;"><i class="fas fa-envelope"></i>abcexample@gmail.com</a>
                <a href="#" class="links"><i class="fas fa-map-marker-alt"></i>Ahmedabad,Gujarat,India</a>

            </div>

            <div class="box">
                <h3>quick links</h3>
                <a href="index.php#home" class="links"><i class="fas fa-arrow-right"></i>home</a>
                <a href="index.php#features" class="links"><i class="fas fa-arrow-right"></i>features</a>
                <a href="index.php#categories" class="links"><i class="fas fa-arrow-right"></i>categories</a>
                <a href="product.php" class="links"><i class="fas fa-arrow-right"></i>products</a>
                <a href="index.php#reviews" class="links"><i class="fas fa-arrow-right"></i>reviews</a>
                <a href="index.php#blogs" class="links"><i class="fas fa-arrow-right"></i>blogs</a>
                <a href="team.php" class="links"><i class="fas fa-arrow-right"></i>About Team</a>
            </div>

            <!-- <div class="box">
                <h3>newsletter</h3>
                <p>subscribe for latest updates</p>
                <input type="email" placeholder="your email" class="email" style="border: 1px solid black;border-radius: .2rem;padding: .5rem 0;text-transform:none;">
                <input type="submit" value="subscribe" class="btn">
                <img src="images/payment-img.png" alt="" class="payment-img">
            </div> -->
        </div>

        <div class="credit">created by <span>SabjiWala.com</span> <span>| all rights reserved</span></div>


    </section>
