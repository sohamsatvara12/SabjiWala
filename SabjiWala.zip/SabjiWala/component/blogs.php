<section class="blogs" id="blogs">
    <h1 class="heading" style="margin-bottom: 2rem;">Our <span>Blogs</span></h1>


    <div class="box-container">

        <div class="box">
            <img src="images/blog/blog1.jpg" alt="">

            <div class="content">
                <div class="icons">
                    <!-- <a href=""><i class="fas fa-user"></i>by User_name</a> -->
                    <a href=""><i class="fas fa-calendar"></i>1st May,2023</a>
                </div>
                <h3>Why Oraganic?</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus, atque!</p>
                <a href="index.php#blogs" class="btn">read more</a>
            </div>


        </div>


        <div class="box">
            <img src="images/blog/blog2.jpg" alt="">

            <div class="content">
                <div class="icons">
                    <!-- <a href=""><i class="fas fa-user"></i>by User_name</a> -->
                    <a href=""><i class="fas fa-calendar"></i>1st May,2023</a>
                </div>
                <h3>The Mango Calendar</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus, atque!</p>
                <a href="index.php#blogs" class="btn">read more</a>
            </div>


        </div>

        <div class="box">
            <img src="images/blog/blog3.jpg" alt="">

            <div class="content">
                <div class="icons">
                    <!-- <a href=""><i class="fas fa-user"></i>by User_name</a> -->
                    <a href=""><i class="fas fa-calendar"></i>1st May,2023</a>
                </div>
                <h3>Secret kitchen hacks</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus, atque!</p>
                <a href="index.php#blogs" class="btn">read more</a>
            </div>

        </div>


    </div>
</section>