<?php

$conn = mysqli_connect('localhost','root','1234','sabjiwala') or die('connection failed');

?>