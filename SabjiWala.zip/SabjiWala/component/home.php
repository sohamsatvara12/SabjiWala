
<section class="home" id="home" >
        <div class="content">
            <h3>Fresh and <span>Organic</span> Products for you</h3>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Tempora ratione at, autem error aut repudiandae quia sequi dolor ipsa dolore.</p>
            <a href="product.php" class="btn">Shop Now</a>

        </div>
    </section>